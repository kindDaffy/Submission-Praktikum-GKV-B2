#include <gl/glut.h>
#include <cmath>

float wheelRotationAngle = 0.0f;

void Trapesium(float topWidth, float bottomWidth, float height) {
    glBegin(GL_QUADS);
    glVertex2f(-topWidth / 2, height / 2);
    glVertex2f(topWidth / 2, height / 2);
    glVertex2f(bottomWidth / 2, -height / 2);
    glVertex2f(-bottomWidth / 2, -height / 2);
    glEnd();
}
void Mobil(void)
{
    glClear(GL_COLOR_BUFFER_BIT);

    // Kotak pertama (badan mobil)
    glPushMatrix();
    glTranslatef(-0.3, 0.0, 0);
    glColor3f(0.0f, 0.0f, 1.0f);
    glRectf(-0.2, 0.1, 0.4, -0.1);
    glPopMatrix();

    // Kotak kedua (kabin mobil)
    glPushMatrix();
    glTranslatef(-0.4, 0.1, 0);
    glColor3f(1.0f, 0.0f, 1.0f);
    glRectf(-0.1, 0.2, 0.1, 0.0);
    glPopMatrix();
    
    // Kotak kedua (kabin mobil)
    glPushMatrix();
    glTranslatef(-0.2, 0.1, 0);
   glColor3f(1.0f, 0.0f, 1.0f);
    glRectf(-0.1, 0.2, 0.1, 0.0);
    glPopMatrix();
    
//    // Kotak kedua (kabin mobil)
//    glPushMatrix();
//    glTranslatef(-0.1, 0.1, 0);
//    glColor3f(1.0f, 0.0f, 1.0f);
//    glRectf(-0.1, 0.1, 0.1, 0.0);
//    glPopMatrix();

	//lampu depan
    glPushMatrix();
    glTranslatef(0.001, -0.02, 0);
    glColor3f(1.0f, 1.0f, 0.0f);
    glRectf(0.0, 0.05, 0.109, 0.0);
    glPopMatrix();
    
    //lampu belakang
    glPushMatrix();
    glTranslatef(-0.5, -0.02, 0);
    glColor3f(1.0f, 0.0f, 0.0f);
    glRectf(0.0, 0.05, 0.05, 0.0);
    glPopMatrix();

//    // Kotak ketiga (atap mobil)
//    glPushMatrix();
//    glTranslatef(-0.3, 0.2, 0);
//    glColor3f(1.0f, 0.0f, 1.0f);
//    glRectf(-0.2, 0.1, 0.2, 0.0);
//    glPopMatrix();
    
	// jendela 
    glColor4f(0.0f, 1.0f, 1.0f, 0.5f); 
    glPushMatrix();
    glTranslatef(-0.1, 0.2, 0.0); 
    Trapesium(0.1, 0.2, 0.2); 
    glPopMatrix();

    // Lingkaran pertama (roda kiri)
    glPushMatrix();
    glTranslatef(-0.4, -0.1, 0);
    glRotatef(wheelRotationAngle, 0.0f, 0.0f, 1.0f); // Rotate the wheel
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_TRIANGLE_FAN);
    GLint circle_points = 100;
    for (int i = 0; i < circle_points; i++)
    {
        float angle = 2.0 * M_PI * i / circle_points;
        glVertex2f(0.07 * cos(angle), 0.07 * sin(angle));
    }
    glEnd();
    glPopMatrix();

    // Lingkaran kedua (roda kanan)
    glPushMatrix();
    glTranslatef(-0.1, -0.1, 0);
    glRotatef(wheelRotationAngle, 0.0f, 0.0f, 1.0f); // Rotate the wheel
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < circle_points; i++)
    {
        float angle = 2.0 * M_PI * i / circle_points;
        glVertex2f(0.07 * cos(angle), 0.07 * sin(angle));
    }
    glEnd();
    glPopMatrix();
    glFlush();
}

void update(int value)
{
    wheelRotationAngle += 2.0f; // Increase the rotation angle
    if (wheelRotationAngle > 360.0f)
        wheelRotationAngle -= 360.0f;

    glutPostRedisplay(); // Request a redraw
    glutTimerFunc(16, update, 0); // Set the next update
}

int main(int argc, char* argv[])
{
    glutInit(&argc, argv);
    glutInitWindowSize(640, 640);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
    glutCreateWindow("Mobil");
    glutDisplayFunc(Mobil);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    
    // Set up the animation
    glutIdleFunc(Mobil);
    glutTimerFunc(25, update, 0);
    glutMainLoop();
    return 0;
}


