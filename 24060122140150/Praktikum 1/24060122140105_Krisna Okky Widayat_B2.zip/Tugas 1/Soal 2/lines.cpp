//Nama		: Krisna Okky Widayat
//NIM		: 24060122140105
//Lab		: B2
//Tanggal	: 25 Februari 2024
//Deskripsi	: Membuat line yang mana titik awal akan tersambung dengan titik kedua dan titik ketiga akan tersambung dengan titik keempat

#include <GL/glut.h>

void lines(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glLineWidth(15.0f);
	glBegin(GL_LINES);
	glColor3f(0.0f,0.0f,0.0f);
	glVertex3f(0.30f,0.30f,0.0);
	glVertex3f(-0.30f,-0.30f,0.0);
	glVertex3f(-0.30f,0.30f,0.0);
	glVertex3f(0.30f,-0.30f,0.0);
	
	glEnd();
	glFlush();
	
}

//int main(int argc, char* argv[])
//{
//	glutInit(&argc, argv);
//	glutInitWindowSize(640,480);
//	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
//	glutCreateWindow("lines");
//	glutDisplayFunc(lines);
//	glClearColor(1.0f,1.0f,1.0f,1.0f);
//	glutMainLoop();
//	return 0;
//}
