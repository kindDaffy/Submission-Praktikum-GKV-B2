//Nama		: Krisna Okky Widayat
//NIM		: 24060122140105
//Lab		: B2
//Tanggal	: 25 Februari 2024
//Deskripsi	: menggabungkan 2 quads yang mana membutuhkan 4 X2 atau lebih  agar quads bisa tersambung dari quads 1 ke quads yang lain

#include <GL/glut.h>

void quadstrip(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0.0f,0.0f,0.0f);
	glBegin(GL_QUAD_STRIP);
	glColor3f(1.0f,0.0f,0.0f);
	glVertex3f(0.0f,0.0f,0.0f);
	glVertex3f(0.0f,0.40f,0.0f);
	glVertex3f(0.20f,0.40f,0.0f);
	glVertex3f(0.20f,0.0f,0.0f);
	glColor3f(1.0f,1.0f,0.0f);
	glVertex3f(0.0f,0.0f,0.0f);
	glVertex3f(0.0f,-0.40f,0.0f);
	glColor3f(0.0f,0.0f,1.0f);
	glVertex3f(0.20f,-0.40f,0.0f);
	glVertex3f(0.20f,0.0f,0.0f);

	glEnd();	
	glFlush();
	
}

//int main(int argc, char* argv[])
//{
//	glutInit(&argc, argv);
//	glutInitWindowSize(640,480);
//	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
//	glutCreateWindow("quadstrip");
//	glutDisplayFunc(quadstrip);
//	glClearColor(0.0f,0.0f,0.0f,0.0f);
//	glutMainLoop();
//	return 0;
//}
