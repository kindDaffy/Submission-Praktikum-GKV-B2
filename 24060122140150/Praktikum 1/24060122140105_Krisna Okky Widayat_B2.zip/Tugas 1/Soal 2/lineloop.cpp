//Nama		: Krisna Okky Widayat
//NIM		: 24060122140105
//Lab		: B2
//Tanggal	: 25 Februari 2024
//Deskripsi	: Membuat lineloop dengan 4 titik, yang mana titik terakhir akan menyambung dnegan titik awal

#include <GL/glut.h>

void lineloop(void)
{
    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_LINE_LOOP);
    glColor3f(0.0f, 0.0f, 1.0f);
	glVertex3f(0.10f, -0.10f, 0.0f);
    glVertex3f(0.80f, 0.05f, 0.0f);
    glVertex3f(0.10f, 0.20f, 0.0f);
    glVertex3f(-0.60f, 0.05f, 0.0f);

    glEnd();
    glFlush();
    
}

//int main(int argc, char* argv[])
//{
//	glutInit(&argc, argv);
//	glutInitWindowSize(640,480);
//	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
//	glutCreateWindow("lineloop");
//	glutDisplayFunc(lineloop);
//	glClearColor(0.0f,0.0f,0.0f,0.0f);
//	glutMainLoop();
//	return 0;
//}
