//Nama		: Krisna Okky Widayat
//NIM		: 24060122140105
//Lab		: B2
//Tanggal	: 24 Februari 2024
//Deskripsi	: Membuat Pacman dari tumpukan kotak

#include <GL/glut.h>
#include <stdlib.h>

void Pacman(void) {
    glClear(GL_COLOR_BUFFER_BIT);
    //badan
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.2, 0.8, 0.35, 0.7);
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.3, 0.7, 0.4, 0.6);
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.4, 0.6, 0.6, 0.5);
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.5, 0.5, 0.7, 0.4);
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.6, 0.4, 0.5, 0.3);
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.6, 0.3, 0.2, 0.2);
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.6, 0.2, 0.0, 0.1);
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.6, 0.1, 0.2, 0.0);
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.6, 0.0, 0.5, -0.1);
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.5, -0.1, 0.7, -0.2);
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.4, -0.2, 0.6, -0.3);
    glColor3f(1.0, 1.0, 0.0);
    glRectf(-0.3, -0.3, 0.4, -0.4);



    //mata
    glColor3f(0.0, 0.0, 0.0);
    glRectf(-0.1, 0.5, 0.0, 0.4);
    
    glFlush();
}

int main(int argc, char* argv[]){
    glutInit(&argc, argv);
    glutInitWindowSize(640, 640);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
    glutCreateWindow("Pacman");

    // Menetapkan proyeksi ortografis
    glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);

    glutDisplayFunc(Pacman);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glutMainLoop();
    
    return 0;
}

